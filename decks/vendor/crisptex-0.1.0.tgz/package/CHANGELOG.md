# Changelog

All notable changes are listed here. The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and versions follow [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added

- Pixel layout for TeX parsed by KaTeX: scripts, fractions, roots, big operators with limits, stretchy brackets, matrices, `cases`, `aligned`, accents, `\text`, `\mathbb`, `\mathcal` and spacing.
- About 330 hand-drawn text glyphs and a separate script-size set, on a 7-pixel cap grid.
- Output as SVG, canvas or a raw bitmap, at whole-number scales.
- Accessible HTML: hidden MathML for screen readers, and the TeX as invisible text so copying gives the source.
- KaTeX fallback, with a development warning that lists unsupported commands.
- React component, `<crisp-tex>` custom element, remark plugin and reveal.js plugin.
- Bitmap font in TTF and WOFF, under the SIL Open Font License 1.1.
- Golden snapshot tests for 45 formulas, and glyph checks for confusable pairs.
