<p align="center"><img src="docs/banner.svg" alt="TeX to pixels: for all epsilon greater than 0, there exists delta greater than 0" width="100%"></p>

# crisptex

Write normal TeX and get the maths back as pixel art. KaTeX parses the TeX. Hand-drawn bitmap glyphs draw it on one integer grid, and every art pixel lands on a whole number of screen pixels, so edges stay crisp at any scale.

```js
import { toHtml } from "crisptex"

toHtml("\\delta(q, a) = (q', b, R)", { scale: 3 })
```

[Try the live demo](https://varunswaika.github.io/crisptex/): type TeX on the left and see pixels on the right.

> **Status:** pre-release. Nothing is on npm yet.

## What you get

- **The core renderer:** TeX to pixel boxes to SVG or canvas.
- **A React component** and a plain **web component**.
- **A remark plugin** for Markdown and MDX, and a **reveal.js plugin** for slides.
- **A bitmap font** (TTF and WOFF) with the same glyphs, under the SIL Open Font License.

Each formula comes out as an SVG, hidden from screen readers. KaTeX's MathML sits beside it for screen readers, and the TeX source lies over it as invisible text, so selecting and copying a formula gives you its TeX.

## Install

```sh
npm install crisptex katex
```

KaTeX is a peer dependency. React is optional and only needed for `crisptex/react`.

## Use it

### In HTML strings

```js
import { toHtml, toSvg } from "crisptex"

toHtml("\\sum_{i=1}^{n} i = \\frac{n(n+1)}{2}", { display: true, scale: 4 })
toSvg("x^2") // the bare SVG, no wrapper
```

| Option | Default | Meaning |
|---|---|---|
| `display` | `false` | Display style: big operators drawn large, with limits above and below. |
| `scale` | `3` | Screen pixels per art pixel. Rounded to a whole number. |
| `macros` | `{}` | Extra TeX macros, merged over the built-in ones. |

### In React

```jsx
import { PixelMath } from "crisptex/react"

<PixelMath tex="\Box(\mathit{req} \to \Diamond \mathit{grant})" />
```

### In plain HTML

```html
<script type="module" src="https://esm.sh/crisptex/element"></script>
<crisp-tex>\forall x\, \exists y\; (x < y)</crisp-tex>
<crisp-tex display scale="4" tex="\int_0^1 x^2\,dx"></crisp-tex>
```

### In Markdown or MDX

Add the plugin after `remark-math`. Mark a block with `pixel` to draw it in pixels:

```md
$$pixel
\delta(q, a) = (q', b, R)
$$
```

To draw every formula in a file, put `pixelMath: true` in its frontmatter. To draw every formula everywhere, pass `{ all: true }`. Unmarked maths is left for `rehype-katex`.

```js
import remarkMath from "remark-math"
import remarkPixelMath from "crisptex/remark"

export default { markdown: { remarkPlugins: [remarkMath, [remarkPixelMath, { scale: 3 }]] } }
```

### In reveal.js

```js
import PixelMath from "crisptex/reveal"

Reveal.initialize({ plugins: [PixelMath], pixelMath: { scale: 4 } })
```

Write `<span class="crisp-tex">x^2</span>` for inline maths, `<div class="crisp-tex">…</div>` for display maths, or `$$pixel … $$` in slide text.

### On a canvas

```js
import { render, drawBitmap } from "crisptex"

const { bitmap } = render("e^{i\\pi} + 1 = 0")
ctx.fillStyle = "#3b2a1a"
drawBitmap(ctx, bitmap, 10, 10, 3)
```

`render` returns `{ ok, unsupported, bitmap }`. The bitmap is a row-major `Uint8Array` with its width, height and depth below the baseline.

## Supported TeX

| Construct | Commands |
|---|---|
| Scripts | `x^2`, `x_i`, `x_i^2`, primes `x'` |
| Fractions | `\frac`, `\dfrac`, `\tfrac` |
| Roots | `\sqrt{x}` |
| Big operators | `\sum`, `\prod`, `\int`, `\bigcup`, `\bigcap`, with limits in display style |
| Named operators | `\log`, `\lim`, `\max`, `\gcd`, `\Pr`, `\bmod`, `\pmod`, `\operatorname{…}` |
| Stretchy brackets | `\left`, `\right` with `( ) [ ] \{ \} \langle \rangle \lfloor \rfloor \lceil \rceil \| \|`, tiled from pixel pieces |
| Environments | `matrix`, `pmatrix`, `bmatrix`, `vmatrix`, `cases`, `aligned`, `array` |
| Fonts | `\text`, `\mathbb`, `\mathcal`, `\mathrm`, `\mathit`, `\mathbf` (drawn upright) |
| Accents | `\hat`, `\bar`, `\vec`, `\tilde`, `\dot`, `\ddot`, `\check`, `\overline`, `\underline` |
| Spacing | `\,`, `\:`, `\;`, `\quad`, `\qquad`, `\ `, `\!`, `\kern`, `\hspace` |
| Classes | `\mathrel`, `\mathbin`, `\mathop`, `\mathord` |

Built-in macros for theory of computation: `\blank` (⊔), `\head` (▾), `\Lmove` (◂), `\Rmove` (▸), `\qacc`, `\qrej`, `\qstart`. For temporal logic: `\G`, `\F`, `\X`, `\U`. For probability: `\E` (𝔼).

<!-- commands -->
150 symbol commands, plus `\mathbb{N}` `\mathbb{Z}` `\mathbb{Q}` `\mathbb{R}` `\mathbb{C}` `\mathbb{P}` `\mathbb{B}` `\mathbb{E}`, 5 big operators with limits, and every ASCII letter, digit and sign.

| | | |
|---|---|---|
| ∀ `\forall` | ∃ `\exists` | ∄ `\nexists` |
| ¬ `\neg` `\lnot` | ∧ `\land` `\wedge` | ∨ `\lor` `\vee` |
| → `\to` `\rightarrow` `\rightarrowtail` | ← `\leftarrow` `\gets` | ↔ `\leftrightarrow` |
| ⟶ `\longrightarrow` | ⇒ `\Rightarrow` `\implies` | ⇐ `\Leftarrow` |
| ⇔ `\Leftrightarrow` `\iff` `\leftrightarrows` | ↦ `\mapsto` | ↑ `\uparrow` |
| ↓ `\downarrow` | ⊢ `\vdash` | ⊨ `\models` |
| ⊤ `\top` | ⊥ `\bot` `\perp` | ∈ `\in` |
| ∉ `\notin` | ∋ `\ni` | ⊆ `\subseteq` |
| ⊂ `\subset` | ⊇ `\supseteq` | ⊃ `\supset` |
| ⊊ `\subsetneq` | ∪ `\cup` | ∩ `\cap` |
| ∅ `\emptyset` `\varnothing` | × `\times` | ∖ `\setminus` |
| \ `\backslash` `\textbackslash` | ≠ `\neq` `\ne` | ≤ `\leq` `\le` `\leqslant` |
| ≥ `\geq` `\ge` `\geqslant` | ≡ `\equiv` | ≈ `\approx` |
| ∼ `\sim` | ≅ `\cong` | · `\cdot` `\cdotp` |
| ÷ `\div` | ± `\pm` | ∓ `\mp` |
| ∗ `\ast` `\textasteriskcentered` | ∘ `\circ` | ∞ `\infty` |
| ∂ `\partial` | ∇ `\nabla` | … `\ldots` `\dots` `\mathellipsis` |
| ⋯ `\cdots` | ′ `\prime` | ∣ `\mid` |
| \| `\vert` `\lvert` `\rvert` | ‖ `\Vert` `\lVert` `\rVert` | ⌊ `\lfloor` |
| ⌋ `\rfloor` | ⌈ `\lceil` | ⌉ `\rceil` |
| ⟨ `\langle` `\lang` | ⟩ `\rangle` `\rang` | { `\lbrace` |
| } `\rbrace` | ∑ `\sum` | ∏ `\prod` |
| ∫ `\int` | ⋃ `\bigcup` | ⋂ `\bigcap` |
| ⊔ `\sqcup` `\blank` | ▾ `\head` `\blacktriangledown` `\bigtriangledown` | ◂ `\Lmove` `\blacktriangleleft` |
| ▸ `\Rmove` `\blacktriangleright` `\vartriangleright` `\triangleright` | □ `\Box` `\square` | ◇ `\Diamond` `\lozenge` |
| ○ `\bigcirc` | α `\alpha` | β `\beta` |
| γ `\gamma` | δ `\delta` | ε `\epsilon` `\varepsilon` |
| ζ `\zeta` | η `\eta` | θ `\theta` |
| ι `\iota` | κ `\kappa` `\varkappa` | λ `\lambda` |
| μ `\mu` | ν `\nu` | ξ `\xi` |
| ο `\omicron` | π `\pi` | ρ `\rho` |
| σ `\sigma` | ς `\varsigma` | τ `\tau` |
| υ `\upsilon` | φ `\phi` `\varphi` | χ `\chi` |
| ψ `\psi` | ω `\omega` | Γ `\Gamma` |
| Δ `\Delta` | Θ `\Theta` | Λ `\Lambda` |
| Ξ `\Xi` | Π `\Pi` | Σ `\Sigma` |
| Υ `\Upsilon` | Φ `\Phi` | Ψ `\Psi` |
| Ω `\Omega` | [ `\lbrack` | ] `\rbrack` |
| < `\lt` | > `\gt` | : `\colon` |
| . `\ldotp` | ℓ `\ell` | ħ `\hbar` |
| ℵ `\aleph` | ∠ `\angle` | ∥ `\parallel` |
| ≪ `\ll` | ≫ `\gg` | ∝ `\propto` |
| ⋆ `\star` | • `\bullet` | ⊕ `\oplus` |
| ⊗ `\otimes` | ⋮ `\vdots` | ⋱ `\ddots` |
| △ `\triangle` `\vartriangle` | ≺ `\prec` | ≻ `\succ` |
| ∤ `\nmid` | ϑ `\vartheta` | ϖ `\varpi` |
| ϱ `\varrho` | ⟹ `\Longrightarrow` | ⟺ `\Longleftrightarrow` |
| ⟵ `\longleftarrow` | ⟸ `\Longleftarrow` | ⟼ `\longmapsto` |
| ↪ `\hookrightarrow` | ⇌ `\rightleftharpoons` | ⊈ `\nsubseteq` |
| ⊋ `\supsetneq` | _ `\textunderscore` | $ `\textdollar` |
<!-- /commands -->

## What happens with unsupported TeX

If a formula uses something the pixels cannot draw, such as `\binom` or `\sqrt[3]{x}`, the whole formula falls back to KaTeX's normal output. Outside production, the console names the missing commands once per formula:

```
[crisptex] KaTeX fallback for "\\binom{n}{k}": unsupported \binom
```

Invalid TeX falls back the same way instead of throwing. Call `render()` to check a formula without rendering it: `ok` is `false` and `unsupported` lists the missing commands.

## The grid

- Capitals are 7 pixels tall, x-height is 5, and descenders are 2.
- Scripts use their own hand-drawn set, 5 pixels tall, instead of shrunk text glyphs.
- The maths axis, where fraction bars and minus signs sit, is row 3.
- One blank column separates glyphs. Spacing between atoms follows TeX's classes in whole pixels.

These confusable pairs are drawn differently on purpose, and a test keeps them apart: ∈ and ε, ⊂ and ⊆, − and -, × and 𝑥, 0 and O, l and 1 and I.

Pixel maths suits display formulas, diagrams, slides and game-like scenes. In running body text at small sizes, normal KaTeX is easier to read.

## The font

`font/crisptex.ttf` and `font/crisptex.woff` hold every text-size glyph. One art pixel is 100 units and the em is 11 pixels, so set the font size to a multiple of 11px (11, 22, 33) for exact pixels. Use `image-rendering: pixelated` on canvases, and turn off font smoothing if your platform allows it.

## How it differs from other projects

- [m-sarabi/pixel-math](https://github.com/m-sarabi/pixel-math) is the closest: a web app that turns LaTeX into 1-bit pixel art with hand-drawn glyphs. It has its own parser and exports canvas or PNG. It is not an npm package and has no SVG output, components, plugins, font or fallback.
- [gurki/pixeltex](https://github.com/gurki/pixeltex) is a playful LaTeX and emoji typesetter on a canvas, with a much smaller 3×4 font.
- Bitmap fonts such as GNU Unifont cover the maths Unicode blocks but do no maths layout.
- [hfmath](https://github.com/LingDong-/hfmath) draws LaTeX with single-line Hershey fonts: vector strokes, not a pixel grid.

This project uses KaTeX's parser instead of its own, so it accepts the same TeX as KaTeX and falls back to KaTeX cleanly.

## Tests

Needs Node 22.18 or newer.

```sh
npm install
npm test
```

## Licence

Code: MIT, see [LICENSE](LICENSE). Glyphs and font: SIL Open Font License 1.1, see [font/OFL.txt](font/OFL.txt).
